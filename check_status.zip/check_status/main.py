#!/usr/bin/env python
# -*- encoding: utf-8 -*-

import time
import requests


header = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36'
}


def check(url, s):
    while(True):
        res = requests.get(url, headers=header)
        print('Status Code: ', res)
        time.sleep(s)


if __name__ == '__main__':
    try:
        url = input("Check Url: ")
        s = float(input("Sleep Time(second): "))
        check(url, s)
    except KeyboardInterrupt:
        pass
