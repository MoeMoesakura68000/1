#! /bin/bash
pypy3 start.py CFB 'https://user.xn--nos885i.com/captcha/registera' 5 699 socks5.txt 600 999999
