#! /bin/bash
python3 start.py CFB 'https://user.xn--nos885i.com/captcha/registera' 1 699 http.txt 600 999999
